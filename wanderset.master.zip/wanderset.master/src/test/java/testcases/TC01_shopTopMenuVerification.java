package testcases;

import static org.testng.Assert.assertEquals;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import enums.URl;
import pages.HomePage;
import utils.DriverUtils;

public class TC01_shopTopMenuVerification {
	
	static Actions action;
	static WebDriver d;
	static WebElement element;
	
	@BeforeClass
	public static void setUp() {
		System.setProperty("webdriver.chrome.driver", "C:\\chromedriver.exe");
		d = new ChromeDriver();
		action = new Actions(d);
		d.get("https://www.wanderset.com");
	}
	
	
	@Test
	public static void verifyShopTopMenu () throws Throwable {
		element = d.findElement(By.xpath("//li[@data-dropdown='shop']/a"));
		action.moveToElement(element).click().build().perform();
		isPresent_SubMenu(element, "shop", URl.SHOP.getURL());
		
	}

	@Test
	public static void verifyShopSubMenu () throws Throwable {
		
		
		
		//d.findElement(By.xpath("//li[@data-dropdown='shop']/a")).click();
		element = d.findElement(By.xpath("//li[@data-dropdown='shop']/a"));
    	WebElement allFooterelement = d.findElement(By.xpath("//a[text()='All footwear']"));
    	WebElement boots = d.findElement(By.xpath("//a[text()='boots']"));
    	WebElement shoecare = d.findElement(By.xpath("//a[text()='shoe care']"));
    	WebElement shoes = d.findElement(By.xpath("//a[text()='shoes']"));
    	WebElement slides = d.findElement(By.xpath("//a[text()='slides']"));
    	WebElement sneakers = d.findElement(By.xpath("//a[text()='sneakers']"));
    	
    	//action = new Actions(d);
    	action.moveToElement(element).build().perform();
    	String isPresentAllFooter = allFooterelement.getText();
    	//action.moveToElement(element).moveToElement(allFooterelement).click().build().perform();
    	if(isPresentAllFooter.contains("All Footwear")) {
    		action.moveToElement(element).moveToElement(allFooterelement).click().build().perform();
    		Thread.sleep(20000);
    		String URL = d.getCurrentUrl();
    		Assert.assertEquals(URL, URl.ALLFOOTER.getURL(),"SUB MENU ALL FOOTER IS NOT AVAILABLE");
    		String boots_URI = URl.BOOTS.getURL();
    		isPresent_SubMenu(boots, "Boots", boots_URI );
    		isPresent_SubMenu(shoecare, "shoe care", URl.SHOE_CARE.getURL());
    		isPresent_SubMenu(shoes, "shoes", URl.SHOES.getURL() );
    		isPresent_SubMenu(slides, "slides", URl.SLIDES.getURL() );
    		isPresent_SubMenu(sneakers, "sneakers", URl.SNEAKERS.getURL() );
    		
    		
    		/*action.moveToElement(element).build().perform();
    		String isPresentBOOTS= boots.getText();
    		String isPresentSLIDES= shoecare.getText();
    		String isPresentSHOE_CARE= shoes.getText();
    		String isPresentSHOES= slides.getText();
    		String isPresentSNEAKERS= sneakers.getText();*/
    		
    		
    	}else{
    		System.out.println("Fail");
    	}
    	
    	
    	
    	
    /*	boolean isPresentShopTopMenu = element.isDisplayed();
    	if(isPresentShopTopMenu) {
    		System.out.println("All Footer link is displayed ");
    		List<WebElement> verifyAllFooter = d.findElements(By.xpath("//*[text() = 'All footwear']/../../li[@class='list-dropdown-menu__item']"));
    		 System.out.println("Size of List: "+verifyAllFooter.size());
    	        for(WebElement e : verifyAllFooter) 
    	        {        
    	        	
    	        	System.out.print("Text within the SubMenu text "+e.getText()+"\t");
    	            System.out.println("Anchor: "+e.getAttribute("href"));
    	        }
    	}else {
    		System.out.println("Fail");
    	}*/
		
		
		
	}
	
	@Test
	public static void verifySubMenuCount () {
		 
		 List<WebElement> verifyAllFooter = d.findElements(By.xpath("//*[text() = 'All footwear']/../../li[@class='list-dropdown-menu__item']"));
		 //System.out.println("Size of List: "+verifyAllFooter.size());
		 int countSubMenu = verifyAllFooter.size();
		 Assert.assertEquals(countSubMenu,"6","SUB MENU TOTAL COUNT IS NOT AS PER REQUIREMENT");
	}
	
	
	
	public static void isPresent_SubMenu(WebElement element, String subMenu , String URl) throws Throwable {
		action.moveToElement(element).build().perform();
		String isPresent= element.getText();
		if(isPresent.contains(subMenu)) {
			Thread.sleep(20000);
    		String URL = d.getCurrentUrl();
    		Assert.assertEquals(URL, URl,"SUB MENU "+subMenu+ "IS NOT AVAILABLE");
    		System.out.println(subMenu + " : PASS");
		}
	}
	
	@AfterClass
    public void tearDown(){
        d.quit();
    }
	
	
	
}

package enums;

public enum URl {
    BASEURL("http://www.wanderset.com");
    

    String url;

    URl(String url){
        this.url = url;
    }

    public String getURL() {
        return url;
    }
}
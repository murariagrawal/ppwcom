package com.cucumber.selenium;

import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.concurrent.TimeUnit;
import java.util.logging.Logger;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
//import org.openqa.selenium.phantomjs.PhantomJSDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
//import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class seleniumFunction {

	public static WebDriver driver = null;
	public static WebDriverWait waitVar = null;

	public static String baseURL = "http://uhkgast306:4322/dashboard";

	public void createDriver() throws MalformedURLException,
			InterruptedException {
		// PhantomJS
		// File file = new
		// File("C:/Program Files/phantomjs-2.1.1-windows/bin/phantomjs.exe");
		// System.setProperty("phantomjs.binary.path", file.getAbsolutePath());
		// driver = new PhantomJSDriver();

		// new DesiredCapabilities();
		// URL serverurl = new URL("http://localhost:9515");
		// DesiredCapabilities capabilities = DesiredCapabilities.chrome();
		// WebDriver driver = new RemoteWebDriver(serverurl, capabilities);
				//Showing demo
		// Chrome
		System.setProperty("webdriver.chrome.driver", "chromedriver.exe");
		driver = new ChromeDriver();

		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);

		driver.get(baseURL);

		waitVar = new WebDriverWait(driver, 15);
	}

	public void teardown() {
		driver.quit();

	}

	public void isLoginPageDisplayed() throws InterruptedException {
		//Thread.sleep(3000);
		 waitVar.until(ExpectedConditions.presenceOfElementLocated(By
		 .xpath("//button[@class='btn btn-lg btn-primary btn-block login']")));
		
		 driver.findElement(
		 By.xpath("//button[@class='btn btn-lg btn-primary btn-block login']"))
		 .isDisplayed();
	}

	public void enterUsernameandPassword(String arg1, String arg2) {
		driver.findElement(By.xpath("//input[@id='networkId']")).sendKeys(arg1);
		driver.findElement(By.xpath("//input[@id='inputPassword']")).sendKeys(
				arg2);

	}

	public void clickSigninLink() {
		driver.findElement(
				By.xpath("//button[@class='btn btn-lg btn-primary btn-block login']"))
				.click();
	}

	public void isImportLinkDisplayed() throws InterruptedException {
		Thread.sleep(1000);
		waitVar.until(ExpectedConditions.presenceOfElementLocated(By
				.xpath("//ul[@class='nav navbar-nav']/li[1]/a")));
		driver.findElement(By.xpath("//ul[@class='nav navbar-nav']/li[1]/a"))
				.isDisplayed();
	}

	public void clickonLogOut() throws InterruptedException {
		// WebDriverWait wait = new WebDriverWait(driver, 10);
		// wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[@id='signOut']")));
		Thread.sleep(5000);
		WebElement element = driver.findElement(By.xpath("//a[@id='signOut']"));
		JavascriptExecutor executer = (JavascriptExecutor) driver;
		executer.executeScript("arguments[0].click();", element);

	}

	public void clickonImportbtn() throws InterruptedException {
		// TODO Auto-generated method stub
		driver.findElement(By.xpath("//ul[@class='nav navbar-nav']/li[1]/a"))
				.click();
		Thread.sleep(2000);
	}

	public void readExcel() throws InterruptedException {
		driver.findElement(By.xpath("//*[@id='dataImporterArea']")).click();

		String importout = ReadExcel.readexcel().toString().trim();

		// System.out.println("document.getElementById('dataImporterArea').innerHTML='Murari\tAgrawal'");
		WebElement element = driver.findElement(By
				.xpath("//*[@id='dataImporterArea']"));
		JavascriptExecutor jse = (JavascriptExecutor) driver;
		jse.executeScript("arguments[0].value=\'" + importout + "'", element);

		Thread.sleep(1000);
		driver.findElement(By.xpath("//*[@id='parseButton']")).click();
		Thread.sleep(2000);

	}

	public boolean validateDataImportPage() {
		if (driver.findElement(By.xpath("//h1")).isDisplayed()) {
			return true;
		} else {
			return false;
		}

	}

	public void clickonImportbtn_dataImportPage() throws InterruptedException {

		driver.findElement(By.xpath("//*[@id='importButton']")).click();
		Thread.sleep(1000);
		// TODO Auto-generated method stub

	}

	public boolean isAlertPresent() {
		if (driver.switchTo().activeElement()
				.findElement(By.xpath("//button[text()='Close']"))
				.isDisplayed()) {
			System.out.println("Pass");
			return true;
		} else {
			System.out.println("Fail");
			return false;
		}
	}

	public void verifyPOPUPonLoadbutton() throws InterruptedException {
		if (isAlertPresent()) {

			// Log into Report :
			Logger log = Logger.getLogger("Alert Appeares :");
			log.info("Alert :" + driver.switchTo().activeElement().getText());
			// Alert Accept
			driver.switchTo().activeElement()
					.findElement(By.xpath("//button[text()='Close']")).click();
			// Switch to default
			driver.switchTo().defaultContent();
			// Log out

		} else {
			System.out.println("Data Loaded Successfully");

		}

	}

	public void verifyPOPUPonImportbutton() {
		if (isAlertPresent()) {

			// Log into Report :
			Logger log = Logger.getLogger("Alert Appeares :");
			log.info("Alert :" + driver.switchTo().activeElement().getText());
			// Alert Accept
			driver.switchTo().activeElement()
					.findElement(By.xpath("//button[text()='Close']")).click();
			// Switch to default
			driver.switchTo().defaultContent();
			// Log out

		} else {
			System.out.println("Data Imported Successfully");

		}

	}

}

package enums;

public enum URl {
    BASEURL("http://www.wanderset.com"),
    SHOP(""),
	ALLFOOTER("https://www.wanderset.com/products/category/footwear"),
	BOOTS(""),
	SLIDES(""),
	SHOE_CARE(""),
	SHOES(""),
    SNEAKERS("");

    String url;

    URl(String url){
        this.url = url;
    }

    public String getURL() {
        return url;
    }
}
package com.cucumber.stepDefinitions;

import com.cucumber.selenium.ReadExcel;
import com.cucumber.selenium.seleniumFunction;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class CatApplication_FeatureGlue {

	seleniumFunction sf = new seleniumFunction();
	ReadExcel re = new ReadExcel();

	@Given("^User is on CAT LoginPage and user is displayed login screen$")
	public void user_is_on_CAT_LoginPage_and_user_is_displayed_login_screen()
			throws Throwable {
		// Showing Demo of CAT :
		sf.createDriver();
		sf.isLoginPageDisplayed();
	}

	@When("^User enter Username as \"(.*?)\" and Password as \"(.*?)\"$")
	public void user_enter_Username_as_and_Password_as(String arg1, String arg2)
			throws Throwable {
		sf.enterUsernameandPassword(arg1, arg2);
		Thread.sleep(2000);

	}

	@Then("^clicks on Login button$")
	public void clicks_on_Login_button() throws Throwable {
		sf.clickSigninLink();
	}

	@Then("^I see user successfully logged in$")
	public void i_see_user_successfully_logged_in() throws Throwable {
		sf.isImportLinkDisplayed();
		Thread.sleep(1000);
	}

	@Then("^Users clicks on Log out button$")
	public void users_clicks_on_Log_out_button() throws Throwable {
		sf.clickonLogOut();
		Thread.sleep(1000);
	}

	@Then("^User see Login screen$")
	public void user_see_Login_screen() throws Throwable {
		sf.isLoginPageDisplayed();
		Thread.sleep(1000);
		sf.teardown();

	}

	@Then("^Users clicks on Import button$")
	public void users_clicks_on_Import_button() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		sf.clickonImportbtn();
		Thread.sleep(1000);
	}

	@Then("^User see Data Import page$")
	public void user_see_Data_Import_page() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		if (sf.validateDataImportPage()) {
			System.out.println("Import Page is displayed");
		} else {
			System.out.println("Import page is not displayed");
		}
	}

	@Then("^user imports data from excel and clicks on load button$")
	public void user_imports_data_from_excel_and_clicks_on_load_button()
			throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		sf.readExcel();
		
		sf.verifyPOPUPonLoadbutton();

	}

	// // User for Debug
	// public static void main(String[] args) throws Exception {
	// seleniumFunction sf = new seleniumFunction();
	// ReadExcel re = new ReadExcel();
	// sf.createDriver();
	// sf.isLoginPageDisplayed();
	// sf.enterUsernameandPassword("rbatula", "Bwm8963");
	// sf.clickSigninLink();
	// sf.clickonImportbtn();
	// sf.readExcel();
	// sf.verifyPOPUPonLoadbutton();
	// }
	@Then("^user click on Import button$")
	public void user_click_on_Import_button() throws Throwable {
		sf.clickonImportbtn_dataImportPage();
		sf.verifyPOPUPonImportbutton();

	}

	@Then("^user see successfull import message and clicks on Log out button$")
	public void user_see_successfull_import_message_and_clicks_on_Log_out_button()
			throws Throwable {
		// Write code here that turns the phrase above into concrete actions

		sf.clickonLogOut();
		sf.teardown();
	}

}

package pages;

import enums.URl;

import java.util.Iterator;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;


import utils.CommonUtils;

public class HomePage extends CommonUtils {
	
	public static By shop = By.xpath("//li[@data-dropdown='shop']/a");
	public static By allFooter = By.xpath("//a[text()='All footwear']");
	public static By boots = By.xpath("//a[text()='boots']");
	public static By shoeCare = By.xpath("//a[text()='shoe care']");
	public static By shoes = By.xpath("//a[text()='shoes']");
	public static By slides = By.xpath("//a[text()='slides']");
	public static By sneakers =By.xpath("//a[text()='sneakers']");
	public static By verifyAllFooter =By.xpath("//*[text() = 'All footwear']/../../li[@class='list-dropdown-menu__item']");
	static Actions action;
	static WebDriver d;
	
	public static void isPresent_SubMenu(WebElement element, String subMenu, String URl) throws Throwable {
		action.moveToElement(element).build().perform();
		String isPresent = element.getText();
		if (isPresent.contains(subMenu)) {
			Thread.sleep(20000);
			String URL = d.getCurrentUrl();
			Assert.assertEquals(URL, URl, "SUB MENU " + subMenu + "IS NOT AVAILABLE");
			System.out.println(subMenu + " : PASS");
		}
	}
	
	
    
	
	
}

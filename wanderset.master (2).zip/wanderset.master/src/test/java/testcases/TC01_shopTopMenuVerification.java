package testcases;

import static org.testng.Assert.assertEquals;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import enums.URl;
import pages.HomePage;
import utils.DriverUtils;

public class TC01_shopTopMenuVerification {

	static Actions action;
	static WebDriver d;
	static WebElement element;

	@BeforeClass
	public static void setUp() {
		System.setProperty("webdriver.chrome.driver", "C:\\chromedriver.exe");
		d = new ChromeDriver ();
		d.get(URl.BASEURL.getURL());
		action = new Actions(d);
	}

	@Test
	public static void verifyShopTopMenu() throws Throwable {
		element = d.findElement(HomePage.shop);
		action.moveToElement(element).click().build().perform();
		HomePage.isPresent_SubMenu(element, "shop", URl.SHOP.getURL());

	}

	@Test
	public static void verifyShopSubMenu() throws Throwable {

		element = d.findElement(HomePage.shop);
		WebElement allFooterelement = d.findElement(HomePage.allFooter);
		WebElement boots = d.findElement(HomePage.boots);
		WebElement shoecare = d.findElement(HomePage.shoeCare);
		WebElement shoes = d.findElement(HomePage.shoes);
		WebElement slides = d.findElement(HomePage.slides);
		WebElement sneakers = d.findElement(HomePage.sneakers);

		action.moveToElement(element).build().perform();
		String isPresentAllFooter = allFooterelement.getText();
		if (isPresentAllFooter.contains("All Footwear")) {
			action.moveToElement(element).moveToElement(allFooterelement).click().build().perform();
			Thread.sleep(20000);
			String URL = d.getCurrentUrl();
			Assert.assertEquals(URL, URl.ALLFOOTER.getURL(), "SUB MENU ALL FOOTER IS NOT AVAILABLE");
			String boots_URI = URl.BOOTS.getURL();
			HomePage.isPresent_SubMenu(boots, "Boots", boots_URI);
			HomePage.isPresent_SubMenu(shoecare, "shoe care", URl.SHOE_CARE.getURL());
			HomePage.isPresent_SubMenu(shoes, "shoes", URl.SHOES.getURL());
			HomePage.isPresent_SubMenu(slides, "slides", URl.SLIDES.getURL());
			HomePage.isPresent_SubMenu(sneakers, "sneakers", URl.SNEAKERS.getURL());

			/*
			 * action.moveToElement(element).build().perform(); String isPresentBOOTS=
			 * boots.getText(); String isPresentSLIDES= shoecare.getText(); String
			 * isPresentSHOE_CARE= shoes.getText(); String isPresentSHOES= slides.getText();
			 * String isPresentSNEAKERS= sneakers.getText();
			 */

		} else {
			System.out.println("Fail");
		}

	}

	@Test
	public static void verifySubMenuCount() {

		List<WebElement> verifyAllFooter = d
				.findElements(HomePage.verifyAllFooter);
		// System.out.println("Size of List: "+verifyAllFooter.size());
		int countSubMenu = verifyAllFooter.size();
		Assert.assertEquals(countSubMenu, "6", "SUB MENU TOTAL COUNT IS NOT AS PER REQUIREMENT");
	}

	/*public static void isPresent_SubMenu(WebElement element, String subMenu, String URl) throws Throwable {
		action.moveToElement(element).build().perform();
		String isPresent = element.getText();
		if (isPresent.contains(subMenu)) {
			Thread.sleep(20000);
			String URL = d.getCurrentUrl();
			Assert.assertEquals(URL, URl, "SUB MENU " + subMenu + "IS NOT AVAILABLE");
			System.out.println(subMenu + " : PASS");
		}
	}*/

	@AfterClass
	public void tearDown() throws Exception {
		d.quit();
	}

}

package com.cucumber.selenium;

import java.io.File;
import java.io.FileInputStream;
import java.text.SimpleDateFormat;
import java.util.Iterator;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DateUtil;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ReadExcel {

	public static StringBuffer readexcel() {
		StringBuffer sb = new StringBuffer();

		try {

			FileInputStream file = new FileInputStream(new File(
					"G5.2_Spain_file.xlsx"));

			// Create Workbook instance holding reference to .xlsx file
			XSSFWorkbook workbook = new XSSFWorkbook(file);

			// Get first/desired sheet from the workbook
			XSSFSheet sheet = workbook.getSheetAt(0);

			// Iterate through each rows one by one
			Iterator<Row> rowIterator = sheet.iterator();
			int i = 0;
			while (rowIterator.hasNext()) {

				Row row = rowIterator.next();
				// For each row, iterate through all the columns
				Iterator<Cell> cellIterator = row.cellIterator();
				System.out.println("Row No:" + ++i);
				StringBuffer sb2= new StringBuffer();
				boolean isDataEmpty=true;
				while (cellIterator.hasNext()) {
					//sb2= new StringBuffer();
					//isDataEmpty=true;
					Cell cell = cellIterator.next();
					// Check the cell type and format accordingly
					switch (cell.getCellType()) {
					case Cell.CELL_TYPE_NUMERIC:
						isDataEmpty=false;
						if (DateUtil.isCellDateFormatted(cell)) {
							String y = new SimpleDateFormat("d-MMM-yy")
									.format(cell.getDateCellValue());
							sb2.append(y + "\t");
						} else
							sb2.append(cell.getNumericCellValue() + "\t");
						break;
					case Cell.CELL_TYPE_STRING:
						isDataEmpty=false;
						sb2.append(cell.getStringCellValue() + "\t");
						break;
					case Cell.CELL_TYPE_BLANK:

						// sb.append(cell.getStringCellValue()+"\t");
						sb2.append(" \t");
					}
				}
				if(!isDataEmpty){
					sb = sb.append(sb2+"\\n");
				}

			}

			file.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return sb;

	}

}

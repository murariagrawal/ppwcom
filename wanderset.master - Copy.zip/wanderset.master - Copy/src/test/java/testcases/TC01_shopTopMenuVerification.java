package testcases;

import static org.testng.Assert.assertEquals;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import pages.HomePage;
import utils.DriverUtils;

public class TC01_shopTopMenuVerification {

	public WebDriver driver;

    @BeforeClass
    public void setUp(){
        driver = DriverUtils.getDriver();

    }
    
    @Test
    public void test_verifyShopTopMenu(){
    	HomePage homepage = new HomePage();
    	homepage.navigateToHomePage();
    	// Verify the SHOP Menu exists
    	WebElement element = driver.findElement(By.linkText("shop"));
    	Actions action = new Actions(driver);
    	action.moveToElement(element).build().perform();
    	    	// Verify Submenu item All Footwear  (if else ) 
    	// kist down all the sub menu and verify that the link is there or not if yes that can be clicked
    	
    	
        
    }

    @AfterClass
    public void tearDown(){
        driver.quit();
    }
	
	
	
}

package pages;

import enums.URl;

import java.util.Iterator;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import utils.CommonUtils;

public class HomePage extends CommonUtils {
	
	public final By SHOP_TOPMENU = By.xpath("//li[@data-dropdown='shop']/a");
	public final By SHOP_SUBMENU_AllFootwear = By.xpath("//a[text()='All footwear']");
	public final By SHOP_SUBMENU_boots = By.xpath("//a[text()='boots']");
	public final By SHOP_SUBMENU_shoecare = By.xpath("//a[text()='shoe care']");
	public final By SHOP_SUBMENU_shoes = By.xpath("//a[text()='shoes']");
	public final By SHOP_SUBMENU_slides = By.xpath("//a[text()='slides']");
	public final By SHOP_SUBMENU_sneakers = By.xpath("//a[text()='sneakers']");
    
	
	public void navigateToHomePage() {
        String url = URl.BASEURL.getURL();
        System.out.println("Navigating to Wanderset.com: " + url);
        navigateToURL(url);
    }
	
	public void verifyTopMenuIsPresent(String topMenuName) {
		
	}

	public void clickLinkByHref(String href, int position) {
        List<WebElement> anchors = _driver.findElements(By.tagName("a"));
        Iterator<WebElement> i = anchors.iterator();
        int j = 0;
        while(i.hasNext()) {
            WebElement anchor = i.next();
            if(anchor.getAttribute("href").contains(href)) {
                j++;
            }
            if(anchor.getAttribute("href").contains(href)
                    && j == position) {
                anchor.click();
                break;
            }
        }
    }
}

package utils;

import org.openqa.selenium.WebDriver;
//import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.chrome.*;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;

import enums.URl;

/**
 * Created by tmaher on 12/22/2015.
 */
public class DriverUtils {

    public static  WebDriver d;
    static Actions action;
    

   
    public static void setUp() {
    	
        d = new ChromeDriver ();
        if ( d == null) {
            d = new ChromeDriver();
        }
       
		
		d.get(URl.BASEURL.getURL());
        
        return;
    }
    

    
       

    
    public static void tearDown() throws Exception {
        d.close();
        d.quit();
    }
}
